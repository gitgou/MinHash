#include "MinHash.h"

int main()
{
	MinHash<UINT_MAX, 1000> oMinHash;
	oMinHash.CalMinHash();

	return 0;
}


