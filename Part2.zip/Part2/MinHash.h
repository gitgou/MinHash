#ifndef __MIN_HASH_H__
#define __MIN_HASH_H__

#include<iostream>
#include<vector>
#include<string>
#include<limits>
#include<bitset>
#include<set>

#include<stdlib.h>
#include<time.h>

#include "Jaccard.h"

using namespace std;

template<unsigned int ROW_NUM = UINT_MAX, unsigned int COL_NUM = 1000>
class MinHash
{
public:
	MinHash(const string& strShingPath="./Shingles/")
	:m_strShinglePath(strShingPath),
	m_vecMinHash(30, vector<unsigned int>(COL_NUM, UINT_MAX))
	,m_vecJaccard(1000, vector<float>(1000, 0.0))
	{
		Initialize();
	}
	
	bool CalMinHash()
	{
		for(int i = 0; i < 1000; ++i)
		{
			//使用set 去重
			//保存文档的 Shingle;
			set<unsigned int> setShingle;
			for(int iIndex = 0; iIndex < 493; ++iIndex)
			{
				setShingle.insert(m_Shingle[i][iIndex]);
			}	
		
			_CalSingleColMinHash(setShingle, i);
		}//end of 1000 documents	
		
		return true;
	}

	bool Initialize()
	{
		srand((unsigned int )time(NULL));
		
		for(int i = 1; i <= 1000; ++i)
		{
			string strFile = m_strShinglePath + "shingle_" + to_string(i) + ".bin"; 
			FILE* fp;
			fp = fopen(strFile.c_str(), "rb");
			if (fp == NULL) {
				std::cout << "File create error, FileName: " << strFile << std::endl;
				return false;
			}
			
			//读取 Shingle 文件
			fread(m_Shingle[i - 1], sizeof(unsigned int), 493, fp);
			fclose(fp);
		}
		
		cout << "Matrix_size: " << m_vecMinHash.size() << "m_vecMinHash[].size: " << m_vecMinHash[0].size() << endl;
		
		return true;
	}
	
	//计算文档 Jaccard Similarity
	void CalJaccardSimilarity()
	{
		for(int i = 0; i < 1000; ++i)
		{	
			for(int j = i + 1; j < 1000; ++j)
			{
				for(int iIndex = 0; iIndex < 493; ++iIndex)
				{
					m_oJaccard.Calcurate(m_Shingle[i][iIndex], m_Shingle[j][iIndex]);	
				}
	
				m_vecJaccard[i][j] = m_oJaccard.GetJaccardSimilarity();
				m_oJaccard.Clear();
			}
		}
	
	}
	
	//重置 P 值
	void ResetP(unsigned long long P){
		m_ullP = P;
	}
	
	~MinHash()
	{
	}

private:
	//	define universal hashing function
	//  𝑥是 shingling 中输出的整数（即特征矩阵中的行号）
	unsigned int _UniversalHash(unsigned int X)
	{
		unsigned long long a = rand();
		unsigned long long b = rand();
		//cout << "a: " << a << ", b: " << b << endl;
		//优化一下，可能越界
		return (((a * X) % m_ullP + b) % m_ullP) % UINT_MAX;
	}
	
	//	计算每个 document 的 MinHash分量
	void _CalSingleColMinHash(const set<unsigned int>& setShingle, unsigned int uCol)
	{
		//用来保存临时 通用哈希求得值			
		for(int iCount = 0; iCount < 30; ++iCount)
		{
				for(auto &ite : setShingle)
				{
					unsigned int uHashVal = _UniversalHash(ite);
					//test bitset operator==
					if(uHashVal < m_vecMinHash[iCount][uCol])
					{
						m_vecMinHash[iCount][uCol] = uHashVal;
						cout << iCount << ", uCol: " << uCol << ", Row: " << ite << ", uHashVal: " << uHashVal << endl;
					}
				} // end of setShingle 
		}// end of 30 Count
	
	}
	

	//获取所有 Shingle 文件描述符
private:
	//Shlingle 文件存放的目录
	std::string m_strShinglePath;
		
	//定义通用哈希函数的 P 值，P是大于N 的素数;
	unsigned long long m_ullP = 4294967311;
	
	//定义一个 30 * 1000 的矩阵记录 1000 篇文档 Shling 经过 30 次排序的 MinHash 值, 初始化为 UINT_MAX
	vector<vector<unsigned int> > m_vecMinHash;

	//保存所有 Shingle 文件内容
	unsigned int m_Shingle[1000][493];

	//	计算 Jaccard Simularity
	Jaccard m_oJaccard;

	//定义矩阵保存 Jaccard Similarity
	vector< vector<float> > m_vecJaccard;
};


#endif
